# Mini-guide : Ajouter une nouvelle police à la fonctionnalité

Pour ajouter une nouvelle police à votre module, suivez ces étapes selon la provenance de la police (Google Fonts ou téléchargée avec fichiers `.woff`/`.woff2`).

---

**Résumé :**
- Google Fonts : import + classe CSS + ajout JS.
- Police téléchargée : fichiers + @font-face + classe CSS + ajout JS.


---

## 1. Ajouter une police Google Fonts

**Étapes :**

1. **Importer la police dans le CSS :**
   - Ouvrez `styles.css` ou `fonts/fonts.css`.
   - Ajoutez en haut du fichier la ligne suivante :
     ```css
     @import url('https://fonts.googleapis.com/css2?family=NomDeLaPolice:wght@400;700&display=swap');
     ```
     (Remplacez `NomDeLaPolice` par le nom exact sur Google Fonts.)

2. **Définir une classe CSS :**
   - Ajoutez dans `styles.css` :
     ```css
     .font-nomdelapolice { font-family: 'NomDeLaPolice', Arial, sans-serif; }
     ```
     (Adaptez le nom de la classe pour qu'il soit unique.)

3. **Ajouter la police au script JS :**
   - Dans `script.js`, dans le tableau `this.fonts`, ajoutez :
     ```javascript
     { name: 'Nom complet', value: "'NomDeLaPolice', Arial, sans-serif", className: 'font-nomdelapolice' }
     ```
     (Le nom complet est celui qui s'affichera dans le menu.)

---

## 2. Ajouter une police téléchargée (fichiers .woff/.woff2)

**Étapes :**

1. **Copier les fichiers de police :**
   - Placez les fichiers `.woff` et `.woff2` dans le dossier `fonts/`.

2. **Déclarer la police dans fonts.css :**
   - Ouvrez `fonts/fonts.css` et ajoutez :
     ```css
     @font-face {
       font-family: 'NomDeLaPolice';
       src: url('NomDeLaPolice-Regular.woff2') format('woff2'),
            url('NomDeLaPolice-Regular.woff') format('woff');
       font-weight: normal;
       font-style: normal;
       font-display: swap;
     }
     @font-face {
       font-family: 'NomDeLaPolice';
       src: url('NomDeLaPolice-Bold.woff2') format('woff2'),
            url('NomDeLaPolice-Bold.woff') format('woff');
       font-weight: bold;
       font-style: normal;
       font-display: swap;
     }
     ```
     (Adaptez les noms des fichiers selon ceux téléchargés.)

     **Pour une police variable** (un seul fichier, plusieurs poids) :
     ```css
     @font-face {
       font-family: 'NomDeLaPolice';
       src: url('NomDeLaPolice-VF.woff2') format('woff2'),
            url('NomDeLaPolice-VF.woff') format('woff');
       font-weight: 100 900;
       font-display: swap;
     }
     ```

3. **Définir une classe CSS :**
   - Ajoutez dans `styles.css` :
     ```css
     .font-nomdelapolice { font-family: 'NomDeLaPolice', Arial, sans-serif; }
     ```

4. **Ajouter la police au script JS :**
   - Dans `script.js`, dans le tableau `this.fonts`, ajoutez :
     ```javascript
     { name: 'Nom complet', value: "'NomDeLaPolice', Arial, sans-serif", className: 'font-nomdelapolice' }
     ```

---

## 3. Mise à jour du menu

- **Vérifiez dans le menu déroulant** que la nouvelle police apparaît bien.
- **Testez le changement de police** sur la page.

---

### Exemple pour la police "Roboto" (Google Fonts)

1. Dans `styles.css` :
   ```css
   @import url('https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap');
   .font-roboto { font-family: 'Roboto', Arial, sans-serif; }
   ```
2. Dans `script.js` :
   ```javascript
   { name: 'Roboto', value: "'Roboto', Arial, sans-serif", className: 'font-roboto' }
   ```

---

### Exemple pour la police "Lexend" téléchargée (fichiers .woff2/.woff)

1. Placez les fichiers dans `fonts/`.
2. Dans `fonts/fonts.css` :
   ```css
   @font-face {
     font-family: 'Lexend';
     src: url('Lexend-Regular.woff2') format('woff2'),
          url('Lexend-Regular.woff') format('woff');
     font-weight: normal;
     font-style: normal;
     font-display: swap;
   }
   @font-face {
     font-family: 'Lexend';
     src: url('Lexend-Bold.woff2') format('woff2'),
          url('Lexend-Bold.woff') format('woff');
     font-weight: bold;
     font-style: normal;
     font-display: swap;
   }
   ```
3. Dans `styles.css` :
   ```css
   .font-lexend { font-family: 'Lexend', Arial, sans-serif; }
   ```
4. Dans `script.js` :
   ```javascript
   { name: 'Lexend', value: "'Lexend', Arial, sans-serif", className: 'font-lexend' }
   ```

