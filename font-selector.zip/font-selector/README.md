# Sélecteur de Police de Texte

Cette fonctionnalité permet aux utilisateurs de changer facilement la police de texte d'un site web. Elle est conçue pour être facilement intégrée dans une extension WordPress.

## Fonctionnalités

- **Bouton flottant** : Un bouton rond bleu pour ouvrir le sélecteur
- **Navigation par flèches** : Changement rapide entre les polices
- **Menu déroulant** : Sélection directe parmi toutes les polices
- **Persistance** : La police choisie est sauvegardée
- **Accessibilité** : Support clavier et polices spécialisées

## Polices disponibles

1. **Arial** - Police standard sans-serif
2. **Verdana** - Police web-safe lisible
3. **Georgia** - Police serif élégante
4. **Open Dyslexic** - Spécialement conçue pour les dyslexiques
5. **Luciole** - Police inclusive française
6. **Atkinson Hyperlegible** - Très haute lisibilité
7. **Inconstant Regular** - Police moderne variable
8. **Accessible-DfA** - Police d'accessibilité

## Structure des fichiers

```
font-selector/
├── index.html          # Page de test
├── styles.css          # Styles principaux
├── script.js           # Logique JavaScript
├── fonts/
│   ├── fonts.css       # Définitions des polices
│   └── [fichiers.woff2] # Fichiers de polices
└── README.md           # Documentation
```

## Installation

1. Téléchargez tous les fichiers
2. Placez les fichiers de polices dans le dossier `fonts/`
3. Incluez les fichiers CSS et JS dans votre page
4. Le sélecteur est prêt à utiliser !

## Intégration WordPress

Pour intégrer dans WordPress :

1. Copiez le contenu de `styles.css` dans votre thème
2. Copiez `script.js` dans votre dossier de scripts
3. Ajoutez le HTML du menu dans votre template
4. Enregistrez les scripts avec `wp_enqueue_script()`

## Personnalisation

- Modifiez les couleurs dans `styles.css`
- Ajoutez de nouvelles polices dans le tableau JavaScript
- Changez la position du bouton via CSS
- Adaptez les styles à votre thème

## Support navigateurs

- Chrome/Edge 60+
- Firefox 55+
- Safari 12+
- Support mobile complet