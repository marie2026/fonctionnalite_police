/**
 * Gestionnaire de sélection de polices
 * Ce module gère l'interface de sélection des polices de caractères
 */

class FontSelector {
    constructor() {
        // Configuration des polices disponibles
        this.fonts = [
            { name: 'Arial', value: 'Arial, sans-serif', className: 'font-arial' },
            { name: 'Verdana', value: 'Verdana, sans-serif', className: 'font-verdana' },
            { name: 'Georgia', value: 'Georgia, serif', className: 'font-georgia' },
            { name: 'Open Dyslexic', value: '"OpenDyslexic", Arial, sans-serif', className: 'font-open-dyslexic' },
            { name: 'Luciole', value: '"Luciole", Arial, sans-serif', className: 'font-luciole' },
            { name: 'Atkinson Hyperlegible', value: '"Atkinson Hyperlegible", Arial, sans-serif', className: 'font-atkinson' },
            { name: 'Inconstant Regular', value: '"Inconstant Regular", Arial, sans-serif', className: 'font-inconstant' },
            { name: 'Accessible-DfA', value: '"Accessible-DfA", Arial, sans-serif', className: 'font-accessible-dfa' }
        ];

        this.currentFontIndex = 0; // Index de la police actuellement sélectionnée
        this.isMenuOpen = false;   // État du menu (ouvert/fermé)
        this.isDropdownOpen = false; // État du menu déroulant

        // Initialisation après chargement du DOM
        this.init();
    }

    /**
     * Initialise le sélecteur de polices
     */
    init() {
        // Récupération des éléments DOM
        this.elements = {
            trigger: document.getElementById('font-selector-trigger'),
            menu: document.getElementById('font-selector-menu'),
            overlay: document.getElementById('overlay'),
            closeBtn: document.getElementById('close-font-selector'),
            prevBtn: document.getElementById('prev-font'),
            nextBtn: document.getElementById('next-font'),
            currentFontDisplay: document.getElementById('current-font-display'),
            currentFontName: document.getElementById('current-font-name'),
            dropdown: document.getElementById('font-dropdown'),
            fontList: document.getElementById('font-list'),
            body: document.body
        };

        // Génération de la liste des polices dans le dropdown
        this.generateFontList();
        
        // Mise à jour de l'affichage initial
        this.updateCurrentFontDisplay();
        
        // Ajout des écouteurs d'événements
        this.bindEvents();

        console.log('FontSelector initialisé avec', this.fonts.length, 'polices disponibles');
    }

    /**
     * Génère la liste des polices dans le menu déroulant
     */
    generateFontList() {
        this.elements.fontList.innerHTML = '';
        
        this.fonts.forEach((font, index) => {
            const fontOption = document.createElement('button');
            fontOption.className = 'font-option';
            fontOption.setAttribute('data-font-index', index);
            
            // Structure de l'option : aperçu + nom
            fontOption.innerHTML = `
                <span class="font-preview ${font.className}">Aa</span>
                <span class="font-name">${font.name}</span>
            `;
            
            // Écouteur pour sélectionner cette police
            fontOption.addEventListener('click', () => {
                this.selectFont(index);
                this.closeDropdown();
            });
            
            this.elements.fontList.appendChild(fontOption);
        });
    }

    /**
     * Attache tous les écouteurs d'événements
     */
    bindEvents() {
        // Ouverture du menu principal
        this.elements.trigger.addEventListener('click', () => this.openMenu());
        
        // Fermeture du menu
        this.elements.closeBtn.addEventListener('click', () => this.closeMenu());
        this.elements.overlay.addEventListener('click', () => this.closeMenu());
        
        // Navigation avec les flèches
        this.elements.prevBtn.addEventListener('click', () => this.previousFont());
        this.elements.nextBtn.addEventListener('click', () => this.nextFont());
        
        // Toggle du dropdown
        this.elements.currentFontDisplay.addEventListener('click', () => this.toggleDropdown());
        
        // Fermeture du dropdown en cliquant à l'extérieur
        document.addEventListener('click', (e) => {
            if (!this.elements.menu.contains(e.target) && this.isDropdownOpen) {
                this.closeDropdown();
            }
        });
        
        // Support clavier
        document.addEventListener('keydown', (e) => this.handleKeydown(e));
    }

    /**
     * Gère les raccourcis clavier
     */
    handleKeydown(e) {
        if (!this.isMenuOpen) return;
        
        switch(e.key) {
            case 'Escape':
                this.closeMenu();
                break;
            case 'ArrowLeft':
                e.preventDefault();
                this.previousFont();
                break;
            case 'ArrowRight':
                e.preventDefault();
                this.nextFont();
                break;
            case 'Enter':
            case ' ':
                if (e.target === this.elements.currentFontDisplay) {
                    e.preventDefault();
                    this.toggleDropdown();
                }
                break;
        }
    }

    /**
     * Ouvre le menu principal
     */
    openMenu() {
        this.isMenuOpen = true;
        this.elements.menu.classList.remove('hidden');
        this.elements.overlay.classList.remove('hidden');
        
        // Focus sur le premier élément interactif
        this.elements.currentFontDisplay.focus();
        
        console.log('Menu ouvert');
    }

    /**
     * Ferme le menu principal
     */
    closeMenu() {
        this.isMenuOpen = false;
        this.elements.menu.classList.add('hidden');
        this.elements.overlay.classList.add('hidden');
        this.closeDropdown();
        
        // Retour du focus au bouton déclencheur
        this.elements.trigger.focus();
        
        console.log('Menu fermé');
    }

    /**
     * Toggle l'affichage du dropdown
     */
    toggleDropdown() {
        if (this.isDropdownOpen) {
            this.closeDropdown();
        } else {
            this.openDropdown();
        }
    }

    /**
     * Ouvre le menu déroulant des polices
     */
    openDropdown() {
        this.isDropdownOpen = true;
        this.elements.dropdown.classList.remove('hidden');
        this.updateActiveFont();
        
        console.log('Dropdown ouvert');
    }

    /**
     * Ferme le menu déroulant des polices
     */
    closeDropdown() {
        this.isDropdownOpen = false;
        this.elements.dropdown.classList.add('hidden');
        
        console.log('Dropdown fermé');
    }

    /**
     * Met à jour l'indicateur de police active dans le dropdown
     */
    updateActiveFont() {
        const options = this.elements.fontList.querySelectorAll('.font-option');
        options.forEach((option, index) => {
            option.classList.toggle('active', index === this.currentFontIndex);
        });
    }

    /**
     * Sélectionne la police précédente
     */
    previousFont() {
        this.currentFontIndex = (this.currentFontIndex - 1 + this.fonts.length) % this.fonts.length;
        this.applyFont();
        this.updateCurrentFontDisplay();
        
        console.log('Police précédente:', this.fonts[this.currentFontIndex].name);
    }

    /**
     * Sélectionne la police suivante
     */
    nextFont() {
        this.currentFontIndex = (this.currentFontIndex + 1) % this.fonts.length;
        this.applyFont();
        this.updateCurrentFontDisplay();
        
        console.log('Police suivante:', this.fonts[this.currentFontIndex].name);
    }

    /**
     * Sélectionne une police spécifique par son index
     */
    selectFont(index) {
        if (index >= 0 && index < this.fonts.length) {
            this.currentFontIndex = index;
            this.applyFont();
            this.updateCurrentFontDisplay();
            
            console.log('Police sélectionnée:', this.fonts[this.currentFontIndex].name);
        }
    }

    /**
     * Applique la police sélectionnée au body
     */
    applyFont() {
        const selectedFont = this.fonts[this.currentFontIndex];
        this.elements.body.style.fontFamily = selectedFont.value;
        
        // Sauvegarde de la préférence (pour persistance)
        localStorage.setItem('selected-font', this.currentFontIndex);
    }

    /**
     * Met à jour l'affichage de la police courante
     */
    updateCurrentFontDisplay() {
        const selectedFont = this.fonts[this.currentFontIndex];
        this.elements.currentFontName.textContent = selectedFont.name;
        
        // Mise à jour de l'état actif dans le dropdown si ouvert
        if (this.isDropdownOpen) {
            this.updateActiveFont();
        }
    }

    /**
     * Charge la police sauvegardée depuis localStorage
     */
    loadSavedFont() {
        const savedFontIndex = localStorage.getItem('selected-font');
        if (savedFontIndex !== null) {
            const index = parseInt(savedFontIndex, 10);
            if (index >= 0 && index < this.fonts.length) {
                this.currentFontIndex = index;
                this.applyFont();
                this.updateCurrentFontDisplay();
                
                console.log('Police restaurée:', this.fonts[this.currentFontIndex].name);
            }
        }
    }
}

// Initialisation lorsque le DOM est chargé
document.addEventListener('DOMContentLoaded', () => {
    const fontSelector = new FontSelector();
    
    // Charge la police sauvegardée s'il y en a une
    fontSelector.loadSavedFont();
    
    console.log('Application de sélection de polices prête');
});

// Export pour utilisation dans d'autres modules (optionnel)
if (typeof module !== 'undefined' && module.exports) {
    module.exports = FontSelector;
}